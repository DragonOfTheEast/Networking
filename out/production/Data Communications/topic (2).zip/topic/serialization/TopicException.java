/*
    Chinagorom Mbraonye
    CSI 4321
 */
package topic.serialization;

import java.util.Objects;

/**
 * @author Chinagorom Mbaraonye
 * @version 1.1
 */
public class TopicException extends Exception{
    private ErrorCode errorCode; //class error code

    /**
     * Class constructor
     * @param errorCode wanted error code
     */
    public TopicException(ErrorCode errorCode){
        Objects.requireNonNull(errorCode, "Errorcode cannot be null");
        this.errorCode = errorCode;
    }

    /**
     * Default constructor
     * @param errorCode error code wanted
     * @param cause cause of error
     */
    public TopicException(ErrorCode errorCode, Throwable cause){
        super(cause);
        Objects.requireNonNull(errorCode, "Errorcode cannot be null");
        this.errorCode = errorCode;
    }

    /**
     * get error code
     * @return return error code
     */
    public ErrorCode getErrorCode(){
        return errorCode;
    }
}
