/*
    Chinagorom Mbaraonye
    CSI 3421
 */
package topic.app.client;

import topic.serialization.Query;
import topic.serialization.Response;
import topic.serialization.TopicConstants;
import topic.serialization.TopicException;

import java.io.IOException;
import java.net.*;
import java.util.Random;

import static java.lang.System.*;

/**
 * @author Chinagorom Mbaraonye
 * @version 1.0
 */
public class Client {
    private static final int TIMEOUT = 3000;
    private static final int MAXTRIES = 5;
    private static final int params = 3;

    public static void main(String[] args) throws IOException {
        if(args.length != params){
            System.err.println("Wrong parameters : <server IP/name> <server port> <requestedPosts>");
            exit(-1);
        }
        client(args);
    }

    private static void client(String[] args) throws IOException {
        InetAddress inetAddress = null;
        try{
            inetAddress = InetAddress.getByName(args[0]);
        } catch (UnknownHostException e) {
            System.err.println("Unknown Host trying to connect");
            exit(-1);
        }catch (SecurityException e){
            System.err.println("Access to connect not allowed");
            exit(-1);
        }

        int portNumber = Integer.parseInt(args[1]);
        int requested = Integer.parseInt(args[2]);

        Random rand = new Random();
        long queryID = Math.abs(rand.nextInt());
        Query query = new Query(queryID, requested);

        DatagramSocket datagramSocket = null;
        try{
            datagramSocket = new DatagramSocket();
        } catch (SocketException e) {
            System.err.println("There was a socket error");
            exit(-1);
        }
        datagramSocket.setSoTimeout(TIMEOUT);
        DatagramPacket datagramPacket= new DatagramPacket(query.encode(), query.encode().length, inetAddress, portNumber);
        DatagramPacket rec = new DatagramPacket(new byte[TopicConstants.MAXPOSTS], TopicConstants.MAXPOSTS);

        try {
            datagramSocket.send(datagramPacket);
        } catch (IOException e) {
            System.err.println("Error sending packet");
            exit(-1);
        }
        int trials = 0;
        boolean stop = false;

        while(!stop){
            if(trials == MAXTRIES){
                System.err.println("Could not get a reply from server in 5 attempts");
                exit(-1);
            }
            try{
                datagramSocket.receive(rec);
                if(!rec.getAddress().equals(inetAddress)){
                    System.err.println("Received reply from unknown source");
                    exit(-1);
                }
                stop = true;
            }catch (SocketTimeoutException e){
                out.println(e.getLocalizedMessage());
                trials++;
                System.err.println("Timed out, " + (MAXTRIES - trials) + " more tries...");
            }
            if(stop){
                try{
                    Response response = new Response(rec.getData());
                    if(response.getQueryID() != queryID){
                        err.println("Non-matching query ids");
                        stop = false;
                    }
                    out.println(response.toString());
                    return;
                }catch (TopicException e){
                    err.println(e.getErrorCode().getErrorMessage());
                    exit(-1);
                }
            }
        }
    }
}
